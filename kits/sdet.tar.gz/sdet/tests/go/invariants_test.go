package sdet

import (
	"os"
	"testing"
)

// Implement I1–I6 against API_URL. Reset state at the start of every test
// and restore the authority to healthy, even on failure.
//
//   I1  Same Idempotency-Key + user → one reservation (50 sequential + 50 concurrent)
//   I2  Never oversell: 200 concurrent reserves on stock 50 → 50 confirmed, 150 rejected
//   I3  After an outage, no reservation remains pending
//   I4  Status only moves pending → confirmed | reversed
//   I5  Same key, different body → 422
//   I6  /health.mode reflects the authority within 5s

func target() string {
	if v := os.Getenv("TARGET"); v != "" {
		return v
	}
	return "reference"
}

func TestI1_IdempotentReplay(t *testing.T) {
	c := NewClient()
	t.Cleanup(func() { _ = c.SetMode("healthy") })
	if err := c.Reset(); err != nil {
		t.Fatal(err)
	}
	Record("I1", target(), false, "not implemented")
	t.Fatal("implement I1: 50 sequential and 50 concurrent replays of the same key")
}

func TestI2_NeverOversell(t *testing.T) {
	c := NewClient()
	t.Cleanup(func() { _ = c.SetMode("healthy") })
	if err := c.Reset(); err != nil {
		t.Fatal(err)
	}
	Record("I2", target(), false, "not implemented")
	t.Fatal("implement I2: 200 concurrent reservations against stock 50")
}

func TestI3_ReplayCompleteness(t *testing.T) {
	c := NewClient()
	t.Cleanup(func() { _ = c.SetMode("healthy") })
	if err := c.Reset(); err != nil {
		t.Fatal(err)
	}
	Record("I3", target(), false, "not implemented")
	t.Fatal("implement I3: down → pending → healthy → no stragglers")
}

func TestI4_StatusMonotonic(t *testing.T) {
	c := NewClient()
	t.Cleanup(func() { _ = c.SetMode("healthy") })
	if err := c.Reset(); err != nil {
		t.Fatal(err)
	}
	Record("I4", target(), false, "not implemented")
	t.Fatal("implement I4: pending only moves to confirmed or reversed")
}

func TestI5_KeyMismatch(t *testing.T) {
	c := NewClient()
	t.Cleanup(func() { _ = c.SetMode("healthy") })
	if err := c.Reset(); err != nil {
		t.Fatal(err)
	}
	Record("I5", target(), false, "not implemented")
	t.Fatal("implement I5: same key, different body → 422")
}

func TestI6_HealthHonesty(t *testing.T) {
	c := NewClient()
	t.Cleanup(func() { _ = c.SetMode("healthy") })
	if err := c.Reset(); err != nil {
		t.Fatal(err)
	}
	Record("I6", target(), false, "not implemented")
	t.Fatal("implement I6: /health.mode follows authority toggles within 5s")
}
