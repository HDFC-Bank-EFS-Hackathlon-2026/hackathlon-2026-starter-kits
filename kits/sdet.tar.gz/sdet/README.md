# Launch Day — Test Engineering kit

`reference` (:8081) and `buggy` (:8082) are **binaries**. There is no API source in this zip.

```
make up
make check TRACK=sdet SDET_LANG=go
```

Implement I1–I6 in `tests/go` (or java / kotlin). Do not modify `checks/` or `authority/`.

AI assistants are allowed. You will defend the result live. A sealed constraint lands at 0:15.
