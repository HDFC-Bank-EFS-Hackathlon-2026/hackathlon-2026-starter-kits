package launchday;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Student Reservation API (Java). Same two launch-day bugs as the Go starter:
 * retries mint a new reservation, and authority outages fail the request.
 */
public class App {
    private static final Gson GSON = new Gson();
    private final Connection db;
    private final HttpClient client;
    private final String authority;

    public App(Connection db, String authority) {
        this.db = db;
        this.authority = authority;
        this.client = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(2)).build();
    }

    public static void main(String[] args) throws Exception {
        String url = env("DATABASE_URL", "jdbc:postgresql://localhost:5432/student");
        String user = env("DATABASE_USER", "launchday");
        String pass = env("DATABASE_PASSWORD", "launchday");
        Connection db = DriverManager.getConnection(url, user, pass);
        App app = new App(db, env("AUTHORITY_URL", "http://127.0.0.1:9000").replaceAll("/$", ""));
        int port = Integer.parseInt(env("PORT", "8080"));
        HttpServer server = HttpServer.create(new InetSocketAddress(port), 0);
        server.createContext("/health", app::health);
        server.createContext("/items", app::items);
        server.createContext("/reservations", app::reservations);
        server.createContext("/admin/reset", app::reset);
        server.createContext("/admin/reconcile", app::reconcile);
        server.start();
        System.out.println("reservation api (java student) :" + port);
    }

    private void health(HttpExchange ex) throws IOException {
        if (preflight(ex)) return;
        write(ex, 200, Map.of("status", "ok", "authority", "healthy", "mode", "live"));
    }

    private void items(HttpExchange ex) throws IOException {
        if (preflight(ex)) return;
        String id = ex.getRequestURI().getPath().replaceFirst("^/items/", "");
        try {
            HttpResponse<String> resp = client.send(
                    HttpRequest.newBuilder(URI.create(authority + "/items/" + id)).GET().timeout(Duration.ofSeconds(2)).build(),
                    HttpResponse.BodyHandlers.ofString());
            raw(ex, resp.statusCode(), resp.body());
        } catch (Exception e) {
            write(ex, 502, Map.of("error", "authority_unreachable"));
        }
    }

    private void reservations(HttpExchange ex) throws IOException {
        if (preflight(ex)) return;
        String path = ex.getRequestURI().getPath();
        if ("POST".equals(ex.getRequestMethod()) && "/reservations".equals(path)) {
            postReserve(ex);
            return;
        }
        if ("GET".equals(ex.getRequestMethod()) && path.startsWith("/reservations/")) {
            getOne(ex, path.substring("/reservations/".length()));
            return;
        }
        if ("GET".equals(ex.getRequestMethod())) {
            list(ex);
            return;
        }
        write(ex, 405, Map.of("error", "method"));
    }

    private void postReserve(HttpExchange ex) throws IOException {
        JsonObject req = GSON.fromJson(new String(ex.getRequestBody().readAllBytes(), StandardCharsets.UTF_8), JsonObject.class);
        String itemId = req.get("itemId").getAsString();
        String userId = req.get("userId").getAsString();
        int qty = req.has("qty") ? req.get("qty").getAsInt() : 1;
        String rid = UUID.randomUUID().toString();
        JsonObject body = new JsonObject();
        body.addProperty("reservationId", rid);
        body.addProperty("itemId", itemId);
        body.addProperty("userId", userId);
        body.addProperty("qty", qty);
        try {
            HttpResponse<String> resp = client.send(
                    HttpRequest.newBuilder(URI.create(authority + "/reservations"))
                            .timeout(Duration.ofSeconds(2))
                            .header("Content-Type", "application/json")
                            .POST(HttpRequest.BodyPublishers.ofString(body.toString()))
                            .build(),
                    HttpResponse.BodyHandlers.ofString());
            String status = resp.statusCode() == 201 ? "confirmed" : "rejected";
            try (PreparedStatement ps = db.prepareStatement(
                    "INSERT INTO reservations (id, item_id, user_id, qty, status) VALUES (?,?,?,?,?)")) {
                ps.setString(1, rid);
                ps.setString(2, itemId);
                ps.setString(3, userId);
                ps.setInt(4, qty);
                ps.setString(5, status);
                ps.executeUpdate();
            }
            write(ex, "confirmed".equals(status) ? 201 : 409,
                    Map.of("reservationId", rid, "status", status, "mode", "live"));
        } catch (Exception e) {
            write(ex, 502, Map.of("error", "authority_unreachable"));
        }
    }

    private void getOne(HttpExchange ex, String id) throws IOException {
        try (PreparedStatement ps = db.prepareStatement(
                "SELECT item_id, user_id, qty, status FROM reservations WHERE id=?")) {
            ps.setString(1, id);
            ResultSet rs = ps.executeQuery();
            if (!rs.next()) {
                write(ex, 404, Map.of("error", "not_found"));
                return;
            }
            write(ex, 200, Map.of(
                    "reservationId", id,
                    "itemId", rs.getString(1),
                    "userId", rs.getString(2),
                    "qty", rs.getInt(3),
                    "status", rs.getString(4),
                    "mode", "live"));
        } catch (Exception e) {
            write(ex, 500, Map.of("error", "query"));
        }
    }

    private void list(HttpExchange ex) throws IOException {
        String user = query(ex, "userId");
        try (PreparedStatement ps = db.prepareStatement(
                "SELECT id, item_id, user_id, qty, status FROM reservations WHERE (? IS NULL OR user_id=?) ORDER BY created_at")) {
            ps.setString(1, user);
            ps.setString(2, user);
            ResultSet rs = ps.executeQuery();
            List<Map<String, Object>> list = new ArrayList<>();
            while (rs.next()) {
                list.add(Map.of(
                        "reservationId", rs.getString(1),
                        "itemId", rs.getString(2),
                        "userId", rs.getString(3),
                        "qty", rs.getInt(4),
                        "status", rs.getString(5),
                        "mode", "live"));
            }
            write(ex, 200, list);
        } catch (Exception e) {
            write(ex, 500, Map.of("error", "query"));
        }
    }

    private void reset(HttpExchange ex) throws IOException {
        if (preflight(ex)) return;
        try {
            db.createStatement().executeUpdate("DELETE FROM reservations");
            write(ex, 200, Map.of("status", "reset"));
        } catch (Exception e) {
            write(ex, 500, Map.of("error", "reset"));
        }
    }

    private void reconcile(HttpExchange ex) throws IOException {
        if (preflight(ex)) return;
        write(ex, 200, Map.of("replayed", 0, "confirmed", 0, "reversed", 0));
    }

    private static boolean preflight(HttpExchange ex) throws IOException {
        ex.getResponseHeaders().add("Access-Control-Allow-Origin", "*");
        ex.getResponseHeaders().add("Access-Control-Allow-Headers", "Content-Type, Idempotency-Key");
        ex.getResponseHeaders().add("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
        if ("OPTIONS".equals(ex.getRequestMethod())) {
            ex.sendResponseHeaders(204, -1);
            return true;
        }
        return false;
    }

    private static void write(HttpExchange ex, int code, Object body) throws IOException {
        byte[] b = GSON.toJson(body).getBytes(StandardCharsets.UTF_8);
        ex.getResponseHeaders().set("Content-Type", "application/json");
        ex.sendResponseHeaders(code, b.length);
        try (OutputStream os = ex.getResponseBody()) {
            os.write(b);
        }
    }

    private static void raw(HttpExchange ex, int code, String body) throws IOException {
        byte[] b = body.getBytes(StandardCharsets.UTF_8);
        ex.getResponseHeaders().set("Content-Type", "application/json");
        ex.sendResponseHeaders(code, b.length);
        try (OutputStream os = ex.getResponseBody()) {
            os.write(b);
        }
    }

    private static String query(HttpExchange ex, String key) {
        String q = ex.getRequestURI().getQuery();
        if (q == null || q.isEmpty()) return null;
        for (String part : q.split("&")) {
            String[] kv = part.split("=", 2);
            if (kv.length == 2 && kv[0].equals(key) && !kv[1].isEmpty()) return kv[1];
        }
        return null;
    }

    private static String env(String k, String def) {
        String v = System.getenv(k);
        return v == null || v.isEmpty() ? def : v;
    }

    @SuppressWarnings("unused")
    private static InputStream unused(InputStream in) {
        return in;
    }
}
