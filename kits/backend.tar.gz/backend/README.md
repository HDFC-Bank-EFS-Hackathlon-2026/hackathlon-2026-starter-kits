# Launch Day — Backend kit

This zip is **only** the Backend track. There is no reference implementation here.

```
make up
make check TRACK=backend
```

Start from `backend/go` (or java / kotlin). Do not modify `authority/` or `checks/`.
AI assistants are allowed. You will defend the result live. A sealed constraint lands at 0:15.
