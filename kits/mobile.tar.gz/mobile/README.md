# Launch Day — Mobile kit

Item list works. Item Detail / Reserve is unfinished.

```
make up
# Reservation API on :8080  ·  Authority on :9000
```

AI assistants are allowed. You will defend the result live. A sealed constraint lands at 0:15.
