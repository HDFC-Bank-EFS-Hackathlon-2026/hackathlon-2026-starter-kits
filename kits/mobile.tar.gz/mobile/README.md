# Launch Day — Mobile kit

Item list works. Item Detail / Reserve is unfinished.

```
make up
# Reservation API on :8080  ·  Authority on :9000
```

AI chatbots such as ChatGPT may be used only for assistance. Automated AI agents, autonomous systems, IDE-integrated AI chatbots/agents, and tools that generate substantial or complete solution code are restricted. You must be able to explain and modify your work live. A sealed constraint lands at 0:15.
