import SwiftUI

@main
struct LiveDropsApp: App {
    var body: some Scene {
        WindowGroup {
            ItemListView(items: [
                DropItem(id: "hype-001", available: 50),
                DropItem(id: "hype-002", available: 20),
                DropItem(id: "hype-003", available: 10),
                DropItem(id: "hype-004", available: 5),
                DropItem(id: "hype-005", available: 100),
            ])
        }
    }
}
