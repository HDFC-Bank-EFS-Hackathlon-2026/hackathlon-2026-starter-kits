import SwiftUI

/// Unfinished. Wire Reserve to ReserveViewModel.
struct ItemDetailView: View {
    let item: DropItem
    @State private var vm = ReserveViewModel()

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("\(item.available) available").font(.largeTitle)
            Text("State: \(vm.state.phase.rawValue) — complete this screen.")
            Spacer()
            Button("Reserve") {
                // TODO: optimistic reserve, reconcile, no double-tap
            }
            .buttonStyle(.borderedProminent)
        }
        .padding()
        .navigationTitle(item.id)
        .onAppear { vm.load(available: item.available) }
    }
}
