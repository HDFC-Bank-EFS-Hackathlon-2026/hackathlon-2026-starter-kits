import SwiftUI

struct DropItem: Identifiable {
    let id: String
    let available: Int
}

struct ItemListView: View {
    let items: [DropItem]
    var body: some View {
        NavigationStack {
            List(items) { item in
                NavigationLink(item.id) {
                    ItemDetailView(item: item)
                }
            }
            .navigationTitle("Live Drops")
        }
    }
}
