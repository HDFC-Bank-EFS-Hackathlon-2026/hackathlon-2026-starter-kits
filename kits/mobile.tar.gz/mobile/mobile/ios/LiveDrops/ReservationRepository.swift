import Foundation

struct RemoteItem: Decodable {
    let itemId: String
    let available: Int
    let name: String?
}

struct RemoteReservation: Decodable {
    let reservationId: String
    let status: String
    let mode: String?
}

final class ReservationRepository {
    let baseURL: URL

    init(baseURL: URL = URL(string: "http://127.0.0.1:8080")!) {
        self.baseURL = baseURL
    }

    func getItem(id: String) async throws -> RemoteItem {
        let (data, _) = try await URLSession.shared.data(from: baseURL.appending(path: "items/\(id)"))
        return try JSONDecoder().decode(RemoteItem.self, from: data)
    }

    func reserve(itemId: String, userId: String, idempotencyKey: String, qty: Int = 1) async throws -> RemoteReservation {
        var req = URLRequest(url: baseURL.appending(path: "reservations"))
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.setValue(idempotencyKey, forHTTPHeaderField: "Idempotency-Key")
        req.httpBody = try JSONSerialization.data(withJSONObject: [
            "itemId": itemId, "userId": userId, "qty": qty,
        ])
        let (data, _) = try await URLSession.shared.data(for: req)
        return try JSONDecoder().decode(RemoteReservation.self, from: data)
    }

    func getReservation(id: String) async throws -> RemoteReservation {
        let (data, _) = try await URLSession.shared.data(from: baseURL.appending(path: "reservations/\(id)"))
        return try JSONDecoder().decode(RemoteReservation.self, from: data)
    }
}
