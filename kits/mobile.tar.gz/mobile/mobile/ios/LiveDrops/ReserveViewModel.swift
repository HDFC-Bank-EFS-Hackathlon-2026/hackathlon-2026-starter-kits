import Foundation

enum ReservePhase: String {
    case idle, optimistic, pending, confirmed, rejected, reversed
}

struct ReserveState {
    var phase: ReservePhase = .idle
    var available: Int = 0
    var message: String = ""
    var reservationId: String?
    var idempotencyKey: String?
}

/// Unfinished. Keep this testable. Generate the idempotency key BEFORE the request fires.
final class ReserveViewModel {
    var state = ReserveState()

    func load(available: Int) {
        state = ReserveState(phase: .idle, available: available)
    }

    func reserve() throws {
        struct Unfinished: Error {}
        throw Unfinished()
    }
}
