class Reservation {
  const Reservation({
    required this.id,
    required this.status,
    this.mode = 'live',
    this.itemId = '',
  });

  final String id;
  final String status;
  final String mode;
  final String itemId;

  factory Reservation.fromJson(Map<String, dynamic> json) => Reservation(
        id: json['reservationId'] as String? ?? '',
        status: json['status'] as String? ?? '',
        mode: json['mode'] as String? ?? 'live',
        itemId: json['itemId'] as String? ?? '',
      );
}
