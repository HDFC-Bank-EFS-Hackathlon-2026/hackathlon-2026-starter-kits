class Item {
  const Item({
    required this.id,
    required this.available,
    this.name = '',
    this.shadowAvailable = 0,
    this.mode = 'live',
  });

  final String id;
  final String name;
  final int available;
  final int shadowAvailable;
  final String mode;

  factory Item.fromJson(Map<String, dynamic> json) => Item(
        id: json['itemId'] as String? ?? '',
        name: json['name'] as String? ?? json['itemId'] as String? ?? '',
        available: (json['available'] as num?)?.toInt() ?? 0,
        shadowAvailable: (json['shadowAvailable'] as num?)?.toInt() ?? 0,
        mode: json['mode'] as String? ?? 'live',
      );
}
