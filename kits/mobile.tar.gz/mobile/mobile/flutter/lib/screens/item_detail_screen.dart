import 'package:flutter/material.dart';

import '../api/reservation_repository.dart';
import '../models/item.dart';
import '../state/reserve_view_model.dart';

/// Unfinished. Wire Reserve to the ViewModel: optimistic update, then reconcile.
class ItemDetailScreen extends StatefulWidget {
  const ItemDetailScreen({super.key, required this.repo, required this.item});

  final ReservationRepository repo;
  final Item item;

  @override
  State<ItemDetailScreen> createState() => _ItemDetailScreenState();
}

class _ItemDetailScreenState extends State<ItemDetailScreen> {
  final vm = ReserveViewModel();

  @override
  void initState() {
    super.initState();
    vm.load(widget.item.available);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.item.name.isEmpty ? widget.item.id : widget.item.name)),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('${vm.state.available} available', style: Theme.of(context).textTheme.headlineMedium),
            const SizedBox(height: 8),
            Text('State: ${vm.state.phase.name} — complete this screen.'),
            const Spacer(),
            FilledButton(
              onPressed: () {
                // TODO: call vm.reserve(), handle pending / revert / no double-tap.
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Reserve is unfinished. See the Mobile brief.')),
                );
              },
              child: const Text('Reserve'),
            ),
          ],
        ),
      ),
    );
  }
}
