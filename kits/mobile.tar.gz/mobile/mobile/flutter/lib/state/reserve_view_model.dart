import 'reserve_state.dart';

/// Unfinished on purpose. Model the state machine explicitly and keep this
/// class unit-testable. Generate the idempotency key BEFORE the request fires.
class ReserveViewModel {
  ReserveState state = const ReserveState();

  void load(int available) {
    state = ReserveState(phase: ReservePhase.idle, available: available);
  }

  /// TODO: implement optimistic reserve + reconcile.
  Future<void> reserve() async {
    throw UnimplementedError('complete Item Detail / Reserve — see the Mobile brief');
  }
}
