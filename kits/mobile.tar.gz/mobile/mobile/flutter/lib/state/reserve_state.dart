enum ReservePhase { idle, optimistic, pending, confirmed, rejected, reversed }

class ReserveState {
  const ReserveState({
    this.phase = ReservePhase.idle,
    this.available = 0,
    this.message = '',
    this.reservationId,
    this.idempotencyKey,
  });

  final ReservePhase phase;
  final int available;
  final String message;
  final String? reservationId;
  final String? idempotencyKey;

  ReserveState copyWith({
    ReservePhase? phase,
    int? available,
    String? message,
    String? reservationId,
    String? idempotencyKey,
  }) {
    return ReserveState(
      phase: phase ?? this.phase,
      available: available ?? this.available,
      message: message ?? this.message,
      reservationId: reservationId ?? this.reservationId,
      idempotencyKey: idempotencyKey ?? this.idempotencyKey,
    );
  }
}
