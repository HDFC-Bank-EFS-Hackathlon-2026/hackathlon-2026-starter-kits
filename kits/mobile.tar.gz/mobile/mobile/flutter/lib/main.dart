import 'package:flutter/material.dart';

import 'api/reservation_repository.dart';
import 'screens/item_list_screen.dart';

void main() {
  runApp(const LiveDropsApp());
}

class LiveDropsApp extends StatelessWidget {
  const LiveDropsApp({super.key});

  @override
  Widget build(BuildContext context) {
    final repo = ReservationRepository();
    return MaterialApp(
      title: 'Live Drops',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF0F6B6B)),
        useMaterial3: true,
      ),
      home: ItemListScreen(repo: repo),
    );
  }
}
