import 'dart:convert';

import 'package:http/http.dart' as http;

import '../models/item.dart';
import '../models/reservation.dart';

class ReservationRepository {
  ReservationRepository({http.Client? client, String? baseUrl})
      : _client = client ?? http.Client(),
        baseUrl = baseUrl ?? const String.fromEnvironment('API_BASE', defaultValue: 'http://127.0.0.1:8080');

  final http.Client _client;
  final String baseUrl;

  Future<List<Item>> listItems() async {
    const ids = ['hype-001', 'hype-002', 'hype-003', 'hype-004', 'hype-005'];
    final items = <Item>[];
    for (final id in ids) {
      items.add(await getItem(id));
    }
    return items;
  }

  Future<Item> getItem(String id) async {
    final res = await _client.get(Uri.parse('$baseUrl/items/$id'));
    if (res.statusCode != 200) {
      throw Exception('getItem ${res.statusCode}');
    }
    return Item.fromJson(jsonDecode(res.body) as Map<String, dynamic>);
  }

  Future<Reservation> reserve({
    required String itemId,
    required String userId,
    required String idempotencyKey,
    int qty = 1,
  }) async {
    final res = await _client.post(
      Uri.parse('$baseUrl/reservations'),
      headers: {
        'Content-Type': 'application/json',
        'Idempotency-Key': idempotencyKey,
      },
      body: jsonEncode({'itemId': itemId, 'userId': userId, 'qty': qty}),
    );
    final body = jsonDecode(res.body) as Map<String, dynamic>;
    return Reservation.fromJson(body);
  }

  Future<Reservation> getReservation(String id) async {
    final res = await _client.get(Uri.parse('$baseUrl/reservations/$id'));
    if (res.statusCode != 200) {
      throw Exception('getReservation ${res.statusCode}');
    }
    return Reservation.fromJson(jsonDecode(res.body) as Map<String, dynamic>);
  }
}
