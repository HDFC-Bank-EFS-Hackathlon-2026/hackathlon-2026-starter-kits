import 'package:flutter_test/flutter_test.dart';
import 'package:live_drops/state/reserve_state.dart';
import 'package:live_drops/state/reserve_view_model.dart';

void main() {
  test('load starts idle with stock', () {
    final vm = ReserveViewModel();
    vm.load(50);
    expect(vm.state.phase, ReservePhase.idle);
    expect(vm.state.available, 50);
  });

  test('reserve is not implemented yet', () async {
    final vm = ReserveViewModel();
    vm.load(50);
    expect(vm.reserve, throwsUnimplementedError);
  });

  // TODO: idle → optimistic → confirmed
  // TODO: idle → optimistic → pending → confirmed
  // TODO: idle → optimistic → pending → reversed
  // TODO: double tap does not create a second reserve
}
