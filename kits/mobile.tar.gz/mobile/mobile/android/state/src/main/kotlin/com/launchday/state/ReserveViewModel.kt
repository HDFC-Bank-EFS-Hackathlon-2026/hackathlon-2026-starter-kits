package com.launchday.state

enum class ReservePhase { Idle, Optimistic, Pending, Confirmed, Rejected, Reversed }

data class ReserveState(
    val phase: ReservePhase = ReservePhase.Idle,
    val available: Int = 0,
    val message: String = "",
    val reservationId: String? = null,
    val idempotencyKey: String? = null,
)

/** Unfinished. Keep this JVM-testable. Generate the key before the request. */
class ReserveViewModel {
    var state: ReserveState = ReserveState()
        private set

    fun load(available: Int) {
        state = ReserveState(phase = ReservePhase.Idle, available = available)
    }

    fun reserve() {
        throw NotImplementedError("complete Item Detail / Reserve — see the Mobile brief")
    }
}
