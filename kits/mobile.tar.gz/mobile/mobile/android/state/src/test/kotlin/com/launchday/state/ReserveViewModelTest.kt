package com.launchday.state

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith

class ReserveViewModelTest {
    @Test
    fun loadStartsIdle() {
        val vm = ReserveViewModel()
        vm.load(50)
        assertEquals(ReservePhase.Idle, vm.state.phase)
        assertEquals(50, vm.state.available)
    }

    @Test
    fun reserveNotImplemented() {
        val vm = ReserveViewModel()
        vm.load(50)
        assertFailsWith<NotImplementedError> { vm.reserve() }
    }
}
