package com.launchday.livedrops.ui

/**
 * Unfinished Compose screen. Wire Reserve to ReserveViewModel:
 * optimistic update, pending poll, revert on rejected/reversed, no double-tap.
 */
class ItemDetailScreen
