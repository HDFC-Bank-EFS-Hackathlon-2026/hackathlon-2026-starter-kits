package com.launchday.livedrops.data

import java.net.HttpURLConnection
import java.net.URL

data class Item(val id: String, val available: Int, val name: String = "")
data class Reservation(val id: String, val status: String, val mode: String = "live")

class ReservationRepository(private val baseUrl: String = "http://10.0.2.2:8080") {
    fun getItem(id: String): Item {
        val conn = URL("$baseUrl/items/$id").openConnection() as HttpURLConnection
        conn.connectTimeout = 2000
        conn.readTimeout = 4000
        val body = conn.inputStream.bufferedReader().readText()
        val available = Regex("\"available\":(\\d+)").find(body)?.groupValues?.get(1)?.toInt() ?: 0
        return Item(id, available, id)
    }

    fun reserve(itemId: String, userId: String, idempotencyKey: String, qty: Int = 1): Reservation {
        val conn = URL("$baseUrl/reservations").openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.doOutput = true
        conn.setRequestProperty("Content-Type", "application/json")
        conn.setRequestProperty("Idempotency-Key", idempotencyKey)
        conn.outputStream.use { it.write("""{"itemId":"$itemId","userId":"$userId","qty":$qty}""".toByteArray()) }
        val body = conn.inputStream.bufferedReader().readText()
        val id = Regex("\"reservationId\":\"([^\"]+)\"").find(body)?.groupValues?.get(1) ?: ""
        val status = Regex("\"status\":\"([^\"]+)\"").find(body)?.groupValues?.get(1) ?: ""
        return Reservation(id, status)
    }

    fun getReservation(id: String): Reservation {
        val conn = URL("$baseUrl/reservations/$id").openConnection() as HttpURLConnection
        val body = conn.inputStream.bufferedReader().readText()
        val status = Regex("\"status\":\"([^\"]+)\"").find(body)?.groupValues?.get(1) ?: ""
        return Reservation(id, status)
    }
}
