import http from "k6/http";
import { sleep, check } from "k6";

export const options = {
  duration: "2m",
  vus: 40,
};

const API = __ENV.API_URL || "http://reference-api:8080";

export default function () {
  const user = `u-${(__VU % 200) + 1}`;
  const key = `${__VU}-${__ITER}`;
  const res = http.post(
    `${API}/reservations`,
    JSON.stringify({ itemId: "hype-001", userId: user, qty: 1 }),
    {
      headers: {
        "Content-Type": "application/json",
        "Idempotency-Key": key,
      },
    }
  );
  check(res, { "not 5xx": (r) => r.status < 500 });
  sleep(0.05);
}
