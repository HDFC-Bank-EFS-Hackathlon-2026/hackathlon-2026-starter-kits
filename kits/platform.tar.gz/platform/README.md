# Launch Day — Platform kit

The Reservation API is a **binary** at `.bin/reference` (no source). Collector pipeline is broken.

```
make up
make check TRACK=platform
```

`make up` starts Postgres and `.bin/reference` on :8081. Then:
`docker compose up -d otel-collector prometheus grafana`

AI assistants are allowed. You will defend the result live. A sealed constraint lands at 0:15.
