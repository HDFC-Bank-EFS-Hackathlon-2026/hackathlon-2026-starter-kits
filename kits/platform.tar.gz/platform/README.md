# Launch Day — Platform kit

The Reservation API is a **binary** at `.bin/reference` (no source). Collector pipeline is broken.

```
make up
make check TRACK=platform
```

`make up` starts Postgres and `.bin/reference` on :8081. Then:
`docker compose up -d otel-collector prometheus grafana`

AI chatbots such as ChatGPT may be used only for assistance. Automated AI agents, autonomous systems, IDE-integrated AI chatbots/agents, and tools that generate substantial or complete solution code are restricted. You must be able to explain and modify your work live. A sealed constraint lands at 0:15.
