# Launch Day — AI / Data Science kit

This zip is **only** the Ask the Drop track. There is no Reservation API and no live model.

```
make check TRACK=ai
```

Start from `ai/ask.py`. Write `ai/out/answers.jsonl` and `ai/out/scores.jsonl`.
Do not modify `checks/` or `ai/data/events.jsonl`.

`make check` is offline. Do not call a hosted model from `run.sh`.

AI chatbots such as ChatGPT may be used only for assistance. Automated AI agents, autonomous systems, IDE-integrated AI chatbots/agents, and tools that generate substantial or complete solution code are restricted. You must be able to explain and modify your work live. A sealed constraint lands at 0:15.
