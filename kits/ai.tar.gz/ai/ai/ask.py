#!/usr/bin/env python3
"""Ask the Drop — candidate skeleton.

Replace this. The starter writes dummy rows so you can see the output shape.
`make check TRACK=ai` fails until answers are grounded and the ranker separates.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
OUT = ROOT / "out"


def read_jsonl(path: Path) -> list[dict]:
    rows = []
    with path.open(encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def write_jsonl(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=True) + "\n")


def main() -> int:
    questions = read_jsonl(DATA / "questions.jsonl")
    events = read_jsonl(DATA / "events.jsonl")

    answers = []
    for q in questions:
        answers.append(
            {
                "questionId": q["questionId"],
                "intent": "other",
                "answerable": True,
                "text": "50 left.",
                "value": 50,
                "freshness": "current",
                "citations": [],
            }
        )

    users = sorted({e["userId"] for e in events if e.get("userId")})
    scores = [{"userId": u, "score": 0.5, "reasons": []} for u in users]

    write_jsonl(OUT / "answers.jsonl", answers)
    write_jsonl(OUT / "scores.jsonl", scores)
    print(f"wrote {len(answers)} answers and {len(scores)} scores (skeleton — checks will fail)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
