# Ask the Drop data

| File | What it is |
|---|---|
| `events.jsonl` | Launch-day log. Do not edit. |
| `questions.jsonl` | Questions asked during the drop. No answers. |
| `intent_train.jsonl` | Labeled intent examples. Wording on eval may differ. |
| `users_train.jsonl` | Labeled `gamer` / `legit` sample. Not everyone. |
| `policy.md` | Published reservation rules for `policy` questions. |

Event `type` values: `stock_snapshot`, `authority_mode`, `reservation_created`,
`reservation_pending`, `reservation_confirmed`, `reservation_rejected`,
`reservation_reversed`, `reservation_released`.

Write outputs to `../out/answers.jsonl` and `../out/scores.jsonl` via `../run.sh`.
