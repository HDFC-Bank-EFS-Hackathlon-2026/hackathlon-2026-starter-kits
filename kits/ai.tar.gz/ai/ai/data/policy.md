# Reservation rules (this drop)

1. Quantity is always 1. You cannot reserve two units on one request.
2. A user may hold at most one open reservation per item at a time.
3. A user may hold reservations on more than one item at a time.
4. If you release a reservation you hold, the unit returns to available stock.
5. A pending reservation (accepted while the authority is unreachable) may later
   become confirmed or reversed. Reversed means the spot was given back.
6. You may only ask about your own reservations. Support will not disclose
   another user's reservation, device, or IP.
7. Stock numbers come from the launch-day log. If the log does not have the
   fact, the honest answer is that we do not know.
