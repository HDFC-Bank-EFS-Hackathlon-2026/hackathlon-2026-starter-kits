# Ask the Drop — AI / Data Science kit

This zip is **only** the AI / Data Science track. There is no Reservation API
and no live model.

```
make check TRACK=ai
```

Start from `ai/ask.py`. Write `ai/out/answers.jsonl` and `ai/out/scores.jsonl`.
Do not modify `checks/` or `ai/data/events.jsonl`.

The check runner is offline. Do not call a hosted model from `run.sh`.

AI assistants are allowed. You will defend the result live. A sealed constraint
lands at 0:15.
