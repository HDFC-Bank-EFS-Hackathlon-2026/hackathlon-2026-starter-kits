#!/usr/bin/env bash
# Called by `make check TRACK=ai`. Keep these output paths.
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p out
python3 ask.py
